import importlib
import subprocess

try:
    importlib.import_module('pygame')
    print("Pygame is installed on this computer.")
    input("Press Enter to exit...")
except ImportError:
    print("Pygame is not installed on this computer. You need Pygame to run this program.")
    install_pygame = input("Do you want to install Pygame? (y/n): ")
    if install_pygame.lower() == 'y':
        try:
            subprocess.check_call(['pip', 'install', 'pygame'])
            print("Pygame has been successfully installed.")
            input("Press Enter to exit...")
        except subprocess.CalledProcessError as e:
            print("Failed to install Pygame. Error:", e)
            input("Press Enter to exit...")
    else:
        print("Pygame will not be installed.")
        input("Press Enter to exit...")