Hello! Thank you for downloading this program!

Please read the following instructions before running the main script..

1. Make sure you have your dependancies installed!
	- In order to make sure the program works properly on your computer, it is reccomended that you run the "depinstall" script before running the main program.
	- This is in order to enure your system has all the software dependancies needed to run the program properly, it will prompt you to install the dependancies if they are not already on your system.
2. Make sure your folder is unzipped
	- If you downloaded this script in a ".zip" file format, you must first export the main folder somehwere on your computer and run the script from inside there
	- This is because the script calls on resources and files present inside the directory, and these cannot be accessed from within the ".zip"

Please remember to have fun, and report any bugs on the github page!

Have Fun!